package com.vedantu.hiring.apiecommerce.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vedantu.hiring.apiecommerce.modals.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory,Integer> {

}
