package com.vedantu.hiring.apiecommerce.modals;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "inventory") 
public class Inventory {

	@Id
	@GeneratedValue
	@Column(name="id")
	private Integer id;//auto generated id

	@Column(name="itemname")
	private String itemName;//item name generic name

	@Column(name="brandname")
	private String brandName;//brand name

	@Column(name="description")
	private String description;// description of the product in details

	@Column(name="actprice")
	private float actPrice;// actual price

	@Column(name="disprice")
	private float disPrice;// discounted price

	//private List<String>keywords;//for search

	@Column(name="sellerinfo")
	private String sellerInfo;//info of the seller

	@Column(name="totalratingsum")
	private int totalRatingSum;// total sum of ratings given to the product so far

	@Column(name="totalnorating")
	private int totalNoRating; //total number of ratings given to the product so far

	@Column(name="initsinstock")
	private int unitsInStock; // total number of items in stock

	@Column(name="totalunitssold")
	private int totalUnitsSold;// total number of items sold so far 


	@Column(name="isoutofstock")
	private boolean isOutOfStock;// true -> item is out of stock

	@Column(name="isreturnable")
	private boolean isReturnable;// true -> item can be returned

	@Column(name="returnduration")
	private int returnDuration;  // duration in hours in which the item can be returned

	@Column(name="imglink1")
	private String imgLink1;  // link to the image of product to be displayed in User Interface

	@Column(name="imglink2")
	private String imgLink2;  // link to the image of product to be displayed in User Interface

	@Column(name="imglink3")
	private String imgLink3;  // link to the image of product to be displayed in User Interface

	@Column(name="imglink4")
	private String imgLink4;  // link to the image of product to be displayed in User Interface


	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public float getActPrice() {
		return actPrice;
	}
	public void setActPrice(float actPrice) {
		this.actPrice = actPrice;
	}
	public float getDisPrice() {
		return disPrice;
	}
	public void setDisPrice(float disPrice) {
		this.disPrice = disPrice;
	}
	public String getSellerInfo() {
		return sellerInfo;
	}
	public void setSellerInfo(String sellerInfo) {
		this.sellerInfo = sellerInfo;
	}
	public int getTotalRatingSum() {
		return totalRatingSum;
	}
	public void setTotalRatingSum(int totalRatingSum) {
		this.totalRatingSum = totalRatingSum;
	}
	public int getTotalNoRating() {
		return totalNoRating;
	}
	public void setTotalNoRating(int totalNoRating) {
		this.totalNoRating = totalNoRating;
	}
	public int getUnitsInStock() {
		return unitsInStock;
	}
	public void setUnitsInStock(int unitsInStock) {
		this.unitsInStock = unitsInStock;
	}
	public int getTotalUnitsSold() {
		return totalUnitsSold;
	}
	public void setTotalUnitsSold(int totalUnitsSold) {
		this.totalUnitsSold = totalUnitsSold;
	}
	public boolean isOutOfStock() {
		return isOutOfStock;
	}
	public void setOutOfStock(boolean isOutOfStock) {
		this.isOutOfStock = isOutOfStock;
	}
	public boolean isReturnable() {
		return isReturnable;
	}
	public void setReturnable(boolean isReturnable) {
		this.isReturnable = isReturnable;
	}
	public int getReturnDuration() {
		return returnDuration;
	}
	public void setReturnDuration(int returnDuration) {
		this.returnDuration = returnDuration;
	}
	public String getImgLink1() {
		return imgLink1;
	}
	public void setImgLink1(String imgLink1) {
		this.imgLink1 = imgLink1;
	}
	public String getImgLink2() {
		return imgLink2;
	}
	public void setImgLink2(String imgLink2) {
		this.imgLink2 = imgLink2;
	}
	public String getImgLink3() {
		return imgLink3;
	}
	public void setImgLink3(String imgLink3) {
		this.imgLink3 = imgLink3;
	}
	public String getImgLink4() {
		return imgLink4;
	}
	public void setImgLink4(String imgLink4) {
		this.imgLink4 = imgLink4;
	}

}
