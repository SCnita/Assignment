package com.vedantu.hiring.apiecommerce.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vedantu.hiring.apiecommerce.DTO.OrderDto;
import com.vedantu.hiring.apiecommerce.DTO.ResponseMessage;
import com.vedantu.hiring.apiecommerce.services.OrderService;

@RestController
@RequestMapping("/api/order")
public class OrderController {


	@Autowired
	OrderService orderService;

	@ResponseBody
	@RequestMapping(value = "/place", headers = {
	"content-type=application/json" }, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseMessage placeOrder(@RequestBody OrderDto orderDto) {
		ResponseMessage responseMessage=new ResponseMessage();
		String res=orderService.placeOrder(orderDto);

		if(res.charAt(0)=='f') {
			responseMessage.setMessage(res);
			responseMessage.setData(null);
		}
		else {
			responseMessage.setMessage("order placed successfully : order id");
			responseMessage.setData(res);
		}
		return responseMessage;
	}

	@GetMapping(value = "/get/{id}")
	public ResponseMessage getOrderDetailsById(@PathVariable Integer id) {
		return orderService.getOrderDetails(id);
	}
}
