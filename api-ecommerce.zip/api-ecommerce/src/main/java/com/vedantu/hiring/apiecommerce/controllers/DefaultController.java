package com.vedantu.hiring.apiecommerce.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DefaultController {

	
	@GetMapping(value = "/")
	public String welcome() {
		return "<h3>API assignment for vedantu hiring</h3>\r\n" + 
				"<h4>API endpoints </h4>\r\n" + 
				"\r\n" + 
				"POST : /api/account/add ->add account              <br>\r\n" + 
				"<br>\r\n" + 
				"POST : /api/inventory/add ->add item in inventory  <br>\r\n" + 
				"GET : /api/inventory/getall -> get all items in inventory <br>\r\n" + 
				"GET : /api/inventory/get/{id} ->get the details of item having id <br>\r\n" + 
				"<br>\r\n" + 
				"\r\n" + 
				"POST : /api/order/add -> place order <br>\r\n" + 
				"GET : /api/order/get/{id} ->get the details of the order having id<br>";
	}
	
	@GetMapping(value = "/error")
	public String error() {
		return "error occured : this may be not implemented";
	}

}
