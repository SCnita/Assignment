package com.vedantu.hiring.apiecommerce.services;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vedantu.hiring.apiecommerce.DTO.OrderDto;
import com.vedantu.hiring.apiecommerce.DTO.ResponseMessage;
import com.vedantu.hiring.apiecommerce.modals.Inventory;
import com.vedantu.hiring.apiecommerce.modals.Order;
import com.vedantu.hiring.apiecommerce.repositories.OrderRepository;


@Service
public class OrderService {

	@Autowired
	OrderRepository orderRepository;
	@Autowired
	InventoryService inventoryService;
	@Autowired
	AccountService accountService;

	public String callPaymentGateway() {
		//fill payment ref number got from the payment gateway;
		//TODO
		return "abcdref123456";
	}

	public String getOrderId() {
		//TODO
		return "Order123456";
	}

	public boolean isValidPinCode(int pincode) {
		//TODO
		return true;
	}
	
	public String placeOrder(OrderDto orderDto) {

		//		int orderCartCount=orderDto.getItems().size();

		//		String orderId=getOrderId();//get order id

		Order order=new Order();
		//order.getId();//set by auto increment

		order.setUserEmail(orderDto.getUserEmail());

		if(!accountService.isAccountValid(orderDto.getUserEmail())) {
			return "failure :user not valid";
		}

		Integer inventoryId=orderDto.getItems().get(0).getItemId();
		Inventory inventory=inventoryService.getInventoryDetailById(inventoryId);


		if(inventory==null) {
			return "failure : not valid product";
		}

		if(inventory.isOutOfStock()) {
			return "failure : item out of stock";
		}
		if(!isValidPinCode(orderDto.getPincode())) {
			return "failure : item is not deliverd at this pincode or invalid pin code";
		}
		
		order.setItemId(inventoryId);
		order.setModeOfPayment(orderDto.getModeOfPayment());
		order.setPincode(orderDto.getPincode());


		order.setAddressCountry(orderDto.getAddressCountry());
		order.setAddressState(orderDto.getAddressState());
		order.setAddressDistrict(orderDto.getAddressDistrict());
		order.setAddressLandmark(orderDto.getAddressLandmark());
		order.setAddressFirstLine(orderDto.getAddressFirstLine());
		order.setAddressSecondLine(orderDto.getAddressSecondLine());
		order.setAddressThirdLine(orderDto.getAddressThirdLine());



		order.setPrice(inventory.getDisPrice()*inventory.getDisPrice());
		//order.setGst(inventory.getG);
		order.setQuantity(orderDto.getItems().get(0).getQuantity());

		order.setPayRefNo(callPaymentGateway());

		order.setDelivered(false);
		order.setDeliveryTime(null);


		order.setTimeOrderPlaced(new Date().toString());
		order.setReturned(false);
		order.setReturnedTime(null);
		order.setReturnReqTime(null);

		
		if(!inventoryService.decrementUnitsInStock(inventoryId,order.getQuantity())) {
			return "failure : item out of stock : quantity not available";
		}

		Order orderPlaced=orderRepository.save(order);
		if(orderPlaced==null) {
			return "failure";
		}
		else {
			return orderPlaced.getId().toString();

		}

		/*
		for(int i=0;i<orderCartCount;i++) {
			Order order=new Order();	
		}
		 */
	}




	public ResponseMessage getOrderDetails(Integer id) {
		ResponseMessage responseMessage=new ResponseMessage();
		responseMessage.setMessage("No order with this order id");
		responseMessage.setData(null);
		try {
			Optional<Order> optionalOrder=orderRepository.findById(id);
			Order order=optionalOrder.get();
			if(order!=null) {
				responseMessage.setData(order);
				responseMessage.setMessage("Order details with order id :");
			}
		}
		catch(Exception e) {

		}	
		return responseMessage;
	}
}
