package com.vedantu.hiring.apiecommerce.modals;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account") 
public class Account {

	@Id
	@Column(name="email")
	private String email;// email id of the user
	//List <Order> orders; all order done by the user
	//TODO


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
