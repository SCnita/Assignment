package com.vedantu.hiring.apiecommerce.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vedantu.hiring.apiecommerce.DTO.ResponseMessage;
import com.vedantu.hiring.apiecommerce.modals.Inventory;
import com.vedantu.hiring.apiecommerce.services.InventoryService;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

	@Autowired
	InventoryService inventoryService;

	@ResponseBody
	@RequestMapping(value = "/add", headers = {
	"content-type=application/json" }, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseMessage addInventory(@RequestBody Inventory inventory) {
		return inventoryService.addInventory(inventory);
	}
	
	@GetMapping(value = "/getall")
	public ResponseMessage getAllInventory() {
		ResponseMessage responseMessage=new ResponseMessage();
		List<Inventory> inventories=inventoryService.getAllInventories();
		responseMessage.setData(inventories);
		responseMessage.setMessage("All items in inventory");
		return responseMessage;
	}

	@GetMapping(value = "/get/{id}")
	public ResponseMessage getInventoryById(@PathVariable Integer id) {
		ResponseMessage responseMessage=new ResponseMessage();
		Inventory inventory=inventoryService.getInventoryDetailById(id);
		if(inventory!=null) {
			responseMessage.setMessage("success : Inventory details ");
			responseMessage.setData(inventory);	
		}
		else {
			responseMessage.setMessage("failure : no inventory with this id");
		}
		return responseMessage;
	}

}
