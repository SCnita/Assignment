package com.vedantu.hiring.apiecommerce.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vedantu.hiring.apiecommerce.DTO.ResponseMessage;
import com.vedantu.hiring.apiecommerce.modals.Inventory;
import com.vedantu.hiring.apiecommerce.repositories.InventoryRepository;


@Service
public class InventoryService {

	@Autowired
	InventoryRepository inventoryRepository;

	public ResponseMessage addInventory(Inventory inventory) {
		ResponseMessage responseMessage=new ResponseMessage();
		responseMessage.setMessage("failure : Inventory addition failed");
		
		Inventory in= inventoryRepository.save(inventory);
		if(in!=null) {
			responseMessage.setMessage("success : Inventory added by id :");
			responseMessage.setData(in.getId().toString());
		}
		return responseMessage;
	}


	public List<Inventory> getAllInventories(){
		List<Inventory> inventories=inventoryRepository.findAll();		
		return inventories;
	}


	public Inventory getInventoryDetailById(Integer id) {

		Inventory inventory=null;
		try {
			Optional<Inventory> cdata = inventoryRepository.findById(id);
			if(cdata.isPresent()) {
				inventory=cdata.get();
			}
		}
		catch(Exception e) {
			System.out.println("Exception occurred");
		}
		return inventory;

	}

	public boolean decrementUnitsInStock(Integer id,int units) {
		Inventory inventory=null;
		try {
			Optional<Inventory> cdata = inventoryRepository.findById(id);
			if(cdata.isPresent()) {
				inventory=cdata.get();
			}
			else {
				return false;
			}


			//decrement the unit
			int unitsInStock=inventory.getUnitsInStock();
			int unitsSold=inventory.getTotalUnitsSold();
			if((unitsInStock-units)<0) {
				return false;
			}
			inventory.setUnitsInStock(unitsInStock-units);
			inventory.setTotalUnitsSold(unitsSold+units);

			//if unit is zero , isOutOfStock=true;
			if(inventory.getUnitsInStock()<=0) {
				inventory.setOutOfStock(true);
			}
			inventoryRepository.save(inventory);

			return true;
		}
		catch(Exception e) {
			System.out.println("Exception occurred");
		}

		return false;
	}


	public String addUnitsInStock(String id,int units) {
		//TODO
		return "success";
	}


	public String rateTheProduct(String id,int rating) {
		//TODO	
		return "success";
	}

	public List<Inventory> getAllInventoriesByKeyword(List<String> keyword){
		//TODO
		List<Inventory> inventories=new ArrayList<Inventory>();
		//create a set
		return inventories;
	}

}
