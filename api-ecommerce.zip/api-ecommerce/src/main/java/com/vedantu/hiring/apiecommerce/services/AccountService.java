package com.vedantu.hiring.apiecommerce.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vedantu.hiring.apiecommerce.DTO.ResponseMessage;
import com.vedantu.hiring.apiecommerce.modals.Account;
import com.vedantu.hiring.apiecommerce.modals.Order;
import com.vedantu.hiring.apiecommerce.repositories.AccountRepository;

@Service
public class AccountService {

	@Autowired
	AccountRepository accountRepository;
	
	public ResponseMessage addAccount(Account account){
		ResponseMessage responseMessage=new ResponseMessage();
		
		if(isAccountValid(account.getEmail())) {
			responseMessage.setMessage("failure : user already present");
			return responseMessage;
		}
		
		Account savedAccount=accountRepository.save(account);
		if(savedAccount!=null) {
			responseMessage.setMessage("success");
		}
		else {
			responseMessage.setMessage("failure");
		}
		
		return responseMessage;
	}

	public List <Order> getAllOrderByUser(String userEmail){
		List<Order> orders=new ArrayList<>();
		//TODO
		return orders;
	}
	
	public boolean isAccountValid(String id) {
		Optional<Account> accOp=accountRepository.findById(id);
		if(accOp.isPresent()) {
			return true;
		}
		else {
			return false;
		}
	}
}
