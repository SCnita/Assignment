package com.vedantu.hiring.apiecommerce.modals;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "orderss") 
public class Order {

	@Id
	@GeneratedValue
	@Column(name="id")
	private Integer id;// auto generated id

	@Column(name="orderid")
	private String orderId;//for multiple item in single order , orderId will be same , TODO for multiple order

	@Column(name="useremail")
	private String userEmail; // user who is placing the order

	@Column(name="itemid")
	private Integer itemId; // item of the product in inventory which is being ordered

	@Column(name="modeofpayment")
	private int modeOfPayment; // mode of payment of the product

	@Column(name="pincode")
	private int pincode; //pincode of the address

	@Column(name="addresscountry")
	private String addressCountry;// country of the address

	@Column(name="addressstate")
	private String addressState;// state of the address

	@Column(name="addressdistrict")
	private String addressDistrict;// district of the address

	@Column(name="addresslandmark")
	private String addressLandmark;// landmark of the address

	@Column(name="addressfirstline")
	private String addressFirstLine;//first line of address

	@Column(name="addresssecondline")
	private String addressSecondLine;//second line of the address

	@Column(name="addressthirdline")
	private String addressThirdLine;//third line of the address

	@Column(name="price")
	private float price; // price of the item

	@Column(name="gst")
	private float gst; //gst tax on the product

	@Column(name="timeorderplaced")
	private String timeOrderPlaced; //time of placemet of ordered

	@Column(name="quantity")
	private int quantity; // quantity of the item ordered

	@Column(name="payRefNo")
	private String payRefNo; // payment reference number generated from the payment gateway

	@Column(name="isdelivered")
	private boolean isDelivered; // true-> item delevered 

	@Column(name="deliverytime")
	private String deliveryTime; // time of the delivery of the item

	@Column(name="isreturnrequested")
	private boolean isReturnRequested;//true -> return is requested

	@Column(name="returnreqtime")
	private String returnReqTime;// time at which user has requested the return  

	@Column(name="isreturned")	
	private boolean isReturned;// true -> item returned

	@Column(name="returnedtime")
	private String returnedTime;// time at which the itm is returned







	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public int getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(int modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getAddressCountry() {
		return addressCountry;
	}
	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}
	public String getAddressState() {
		return addressState;
	}
	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}
	public String getAddressDistrict() {
		return addressDistrict;
	}
	public void setAddressDistrict(String addressDistrict) {
		this.addressDistrict = addressDistrict;
	}
	public String getAddressLandmark() {
		return addressLandmark;
	}
	public void setAddressLandmark(String addressLandmark) {
		this.addressLandmark = addressLandmark;
	}
	public String getAddressFirstLine() {
		return addressFirstLine;
	}
	public void setAddressFirstLine(String addressFirstLine) {
		this.addressFirstLine = addressFirstLine;
	}
	public String getAddressSecondLine() {
		return addressSecondLine;
	}
	public void setAddressSecondLine(String addressSecondLine) {
		this.addressSecondLine = addressSecondLine;
	}
	public String getAddressThirdLine() {
		return addressThirdLine;
	}
	public void setAddressThirdLine(String addressThirdLine) {
		this.addressThirdLine = addressThirdLine;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getGst() {
		return gst;
	}
	public void setGst(float gst) {
		this.gst = gst;
	}
	public String getTimeOrderPlaced() {
		return timeOrderPlaced;
	}
	public void setTimeOrderPlaced(String timeOrderPlaced) {
		this.timeOrderPlaced = timeOrderPlaced;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getPayRefNo() {
		return payRefNo;
	}
	public void setPayRefNo(String payRefNo) {
		this.payRefNo = payRefNo;
	}
	public boolean isDelivered() {
		return isDelivered;
	}
	public void setDelivered(boolean isDelivered) {
		this.isDelivered = isDelivered;
	}
	public String getDeliveryTime() {
		return deliveryTime;
	}
	public void setDeliveryTime(String deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	public boolean isReturnRequested() {
		return isReturnRequested;
	}
	public void setReturnRequested(boolean isReturnRequested) {
		this.isReturnRequested = isReturnRequested;
	}
	public String getReturnReqTime() {
		return returnReqTime;
	}
	public void setReturnReqTime(String returnReqTime) {
		this.returnReqTime = returnReqTime;
	}
	public boolean isReturned() {
		return isReturned;
	}
	public void setReturned(boolean isReturned) {
		this.isReturned = isReturned;
	}
	public String getReturnedTime() {
		return returnedTime;
	}
	public void setReturnedTime(String returnedTime) {
		this.returnedTime = returnedTime;
	}

}
