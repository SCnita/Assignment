package com.vedantu.hiring.apiecommerce.DTO;

public class Item {

	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Item(Integer itemId, int quantity) {
		super();
		this.itemId = itemId;
		this.quantity = quantity;
	}
	private Integer itemId;
	private int quantity;
}
