package com.vedantu.hiring.apiecommerce.util;

public class ModeOfPayment {

	public static final int NETBANKING=0;
	public static final int UPI=0;
	public static final int CASH_ON_DELIVERY=0;
	public static final int CREDITCARD=0;
	public static final int DEBITCARD=0;
	public static final int WALLET=0;
}
