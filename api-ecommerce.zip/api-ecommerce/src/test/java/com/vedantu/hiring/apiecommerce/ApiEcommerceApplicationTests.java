package com.vedantu.hiring.apiecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
